﻿/*
** Put any custom sql you want run on reinstall in here.
*/